﻿

/// Right click .tt file "Run Custom Tool" to update partial model.
/// Author Petter Liu  http://wintersun.cnblogs.com
