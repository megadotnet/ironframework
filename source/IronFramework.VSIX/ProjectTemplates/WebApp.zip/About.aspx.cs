﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="About.aspx.cs" company="Megadotnet">
//   Copyright (c) 2010-2011 Petter Liu.  All rights reserved. 
// </copyright>
// <summary>
//   The about.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace $safeprojectname$
{
    using System;
    using System.Web.UI;

    /// <summary>
    /// The about.
    /// </summary>
    public partial class About : Page
    {
        #region Methods

        /// <summary>
        /// The page_ load.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #endregion
    }
}