﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IBoServiceContractGenerate.cs" company="Megadotnet">
//   Copyright (c) 2010-2011 Petter Liu.  All rights reserved. 
// </copyright>
// <summary>
//   IBoServiceContractGenerate.cs
// </summary>
// --------------------------------------------------------------------------------------------------------------------

